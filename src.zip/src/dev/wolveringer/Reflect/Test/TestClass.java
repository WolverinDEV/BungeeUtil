package dev.wolveringer.Reflect.Test;

import java.util.Arrays;
import java.util.Collection;

public class TestClass {
	@SuppressWarnings("unused")
	private final Collection<String> a = Arrays.asList("THIS IS A TEST STRING");
}
