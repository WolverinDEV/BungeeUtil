package dev.wolveringer.BungeeUtil.packets;

import dev.wolveringer.BungeeUtil.ClientVersion.BigClientVersion;
import dev.wolveringer.BungeeUtil.packets.Abstract.PacketPlayOut;
import dev.wolveringer.packet.PacketDataSerializer;

public class PacketPlayOutEntityDestroy extends Packet implements PacketPlayOut{
	private int[] entitys;

	public PacketPlayOutEntityDestroy() {
		super(0x13);
	}

	public PacketPlayOutEntityDestroy(int... paramVarArgs) {
		super(0x13);
		this.entitys = paramVarArgs;
	}

	public void read(PacketDataSerializer paramPacketDataSerializer) {
		this.entitys = new int[getVersion().getBigVersion() == BigClientVersion.v1_7?paramPacketDataSerializer.readByte():paramPacketDataSerializer.readVarInt()];
		for(int i = 0;i < this.entitys.length;i++){
			if(getVersion().getBigVersion() == BigClientVersion.v1_7)
				this.entitys[i] = paramPacketDataSerializer.readInt();
			else
				this.entitys[i] = paramPacketDataSerializer.readVarInt();
		}
	}

	public void write(PacketDataSerializer paramPacketDataSerializer) {
		if(getVersion().getBigVersion() == BigClientVersion.v1_7)
			paramPacketDataSerializer.writeByte(this.entitys.length);
		else
			paramPacketDataSerializer.writeVarInt(this.entitys.length);
		for(int i = 0;i < this.entitys.length;i++){
			if(getVersion().getBigVersion() == BigClientVersion.v1_7)
				paramPacketDataSerializer.writeInt(this.entitys[i]);
			else
				paramPacketDataSerializer.writeVarInt(this.entitys[i]);
		}
	}
	
	public int[] getEntitys() {
		return entitys;
	}
	public void setEntitys(int[] entitys) {
		this.entitys = entitys;
	}
}