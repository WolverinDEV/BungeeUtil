package dev.wolveringer.BungeeUtil.packets.Abstract;

public interface PacketPlayOut {}
