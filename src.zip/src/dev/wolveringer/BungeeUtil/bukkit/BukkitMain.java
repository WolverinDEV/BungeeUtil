package dev.wolveringer.BungeeUtil.bukkit;

/*
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class BukkitMain extends JavaPlugin{
	@Override
	public void onEnable() {
		Bukkit.getConsoleSender().sendMessage("§7[§eBungeeUntil§7] §cBungeeUtil is only a plugin for the BungeeCord");
	}

}
*/
public class BukkitMain  {
	
}