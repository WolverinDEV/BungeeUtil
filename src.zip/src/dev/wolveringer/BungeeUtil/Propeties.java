package dev.wolveringer.BungeeUtil;

public class Propeties {
	public static boolean HANDLE_INTERN_PACKET = false; //call event for intern packet?
}
