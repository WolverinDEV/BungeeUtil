package dev.wolveringer.BungeeUtil;

public interface OperationCalback<T> {
	public void done(T response);
}
