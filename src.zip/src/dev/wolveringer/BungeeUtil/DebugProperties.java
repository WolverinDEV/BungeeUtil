package dev.wolveringer.BungeeUtil;

public class DebugProperties {
	public static final boolean RAM_LOGGER = true;
	public static final boolean CONSOHLE_COLORED_OUTPUT = true;
	public static final boolean CONSOHLE_CONNECTION_INFORMATION = true;
	public static final boolean PACKET_ERROR_DISCCONNECT = true;
	public static final boolean PACKET_DEVELOPMENT = true;
	public static final boolean TAB_SCOREBORD_FIX = true;
	public static final boolean WHITELISTED = false;
}
