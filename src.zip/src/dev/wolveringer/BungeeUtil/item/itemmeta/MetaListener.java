package dev.wolveringer.BungeeUtil.item.itemmeta;

import dev.wolveringer.BungeeUtil.item.Item;

public interface MetaListener {
	public void onUpdate(Item is);
}
