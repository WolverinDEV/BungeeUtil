package dev.wolveringer.BungeeUtil.item;

import dev.wolveringer.BungeeUtil.item.ItemStack.Click;

public interface ClickListener {
	public void click(Click click);
}
