package dev.wolveringer.BungeeUtil;

public interface CostumPrintStream {
	public void print(String s);
	public void println(String s);
}