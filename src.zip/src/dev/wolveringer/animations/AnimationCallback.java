package dev.wolveringer.animations;

public interface AnimationCallback {
	public void done();
}
