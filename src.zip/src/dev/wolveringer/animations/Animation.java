package dev.wolveringer.animations;

public class Animation {
	private int PID;
	
	
	public int getPID() {
		return this.PID;
	}
}
