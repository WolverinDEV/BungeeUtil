package dev.wolveringer.animations;

public class AnimatonLoop {

}
