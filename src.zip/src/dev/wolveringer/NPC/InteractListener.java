package dev.wolveringer.NPC;

import dev.wolveringer.BungeeUtil.Player;

public interface InteractListener {
	public void rightClick(Player p);
	public void leftClick(Player p);
}
