package dev.wolveringer.api.datawatcher;

public class BlockData {
	private int data;

	public BlockData(int data) {
		super();
		this.data = data;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}
}
