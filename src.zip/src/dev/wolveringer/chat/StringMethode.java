package dev.wolveringer.chat;

public enum StringMethode {
	LIST_VAR,
	LIST_NOT_NULL_VAR,
	MESSAGE_COLORED,
	MESSAGE_UNCOLORED,
	JSON;
}
