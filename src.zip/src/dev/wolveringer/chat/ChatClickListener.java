package dev.wolveringer.chat;

import dev.wolveringer.BungeeUtil.Player;

public interface ChatClickListener {
	public void click(Player p);
}
