/**
 Contains the HTML parser, tag specifications, and HTML tokeniser.
 */
package org.jsoup.parser;
